<?php
session_start();

$timeout = 300; // 5 menit
$now = time(); // Waktu saat ini

// Periksa apakah session `LAST_ACTIVITY` ada
if (isset($_SESSION['LAST_ACTIVITY'])) {
    $elapsedTime = $now - $_SESSION['LAST_ACTIVITY'];
    
    // Jika waktu yang berlalu lebih dari timeout
    if ($elapsedTime > $timeout) {
        // Hapus semua data session
        session_unset();
        session_destroy();
        // Redirect ke halaman login
        echo "<script language='javascript'>alert('Session Anda Berakhir!'); document.location='../../../index.php';</script>";

        exit();
    }
}

// Perbarui waktu terakhir aktivitas
$_SESSION['LAST_ACTIVITY'] = $now;
?>