<?php
	include "../../koneksi.php";
		$id 		= $_POST['id'];
		$status		= $_POST['status'];


			$in = mysqli_query($con,"UPDATE admin SET perubahan='$status' where id_admin='$id'");
				if($in){
						echo"<script language='javascript'>alert('Berhasil Di Update!'); document.location='../../../view/notaris/home_kanwil.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Update!'); 
					document.location='../../../view/notaris/akun_kanwil/progres_pekerjaan_kanwil_perubahan.php';</script>";
					}
?>	