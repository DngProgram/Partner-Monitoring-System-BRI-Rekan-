<?php
	include "../../koneksi.php";
		$no 		= $_POST['id'];
		$nik		= $_POST['nik'];
		$nama_debitur		= $_POST['nama_debitur'];
		$nama_notaris		= $_POST['nama_notaris'];
		$uker		= $_POST['uker'];
		$jenis_pekerjaan		= $_POST['jenis_pekerjaan'];
		$tgl_penyerahan	= $_POST['tgl_penyerahan'];
		$tgl_covernote	= $_POST['tgl_covernote'];
		$keterangan		= $_POST['keterangan'];


			$in = mysqli_query($con,"UPDATE data_kerjaan SET nik='$nik', nama_debitur='$nama_debitur', unit_kerja='$uker', jenis_pekerjaan='$jenis_pekerjaan', tgl_penyerahan='$tgl_penyerahan', tgl_covernote='$tgl_covernote', keterangan='$keterangan', nama_notaris='$nama_notaris' where id='$no'");
				if($in){
						echo"<script language='javascript'>alert('Berhasil Di Update!'); document.location='../../../view/notaris/home_kanwil.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Update!'); 
					document.location='../../../view/notaris/akun_kanwil/edit_pekerjaan_kanwil.php';</script>";
					}
?>