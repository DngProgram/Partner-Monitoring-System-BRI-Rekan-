<?php
	include "../../koneksi.php";
		$id 		= $_POST['id'];
		$status		= $_POST['status'];
		$keterangan	= $_POST['keterangan'];


			$in = mysqli_query($con,"UPDATE data_kerjaan SET status='$status', catatan='$keterangan' where id='$id'");
				if($in){
						echo"<script language='javascript'>alert('Berhasil Di Update!'); document.location='../../../view/notaris/home_kanwil.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Update!'); 
					document.location='../../../view/notaris/akun_kanwil/progres_pekerjaan_kanwil_aproval1.php';</script>";
					}
?>	