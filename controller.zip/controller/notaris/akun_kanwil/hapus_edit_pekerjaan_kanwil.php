<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../../koneksi.php';

if (isset($_GET['id']) && !isset($_GET['confirm'])) {
    $id = $_GET['id'];
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>Konfirmasi Hapus</title>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </head>
    <body>
        <script>
        Swal.fire({
            title: 'Yakin hapus data ini?',
            text: "Data akan dihapus permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?php echo $_SERVER['PHP_SELF']; ?>?id=<?php echo $id; ?>&confirm=yes";
            } else {
                window.location.href = "../../../view/notaris/akun_kanwil/edit_pekerjaan_kanwil.php";
            }
        });
        </script>
    </body>
    </html>
    <?php
    exit;
}

if (isset($_GET['id']) && isset($_GET['confirm']) && $_GET['confirm'] == 'yes') {
    $id = $_GET['id'];

    $hapus = mysqli_query($con, "DELETE FROM data_kerjaan WHERE id='$id'");

    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>Hapus Data</title>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </head>
    <body>
        <script>
        <?php if ($hapus) { ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil dihapus!',
                showConfirmButton: false,
                timer: 1500
            }).then(() => {
                window.location.href = "../../../view/notaris/akun_kanwil/edit_pekerjaan_kanwil.php";
            });
        <?php } else { ?>
            Swal.fire({
                icon: 'error',
                title: 'Gagal menghapus!',
                showConfirmButton: false,
                timer: 1500
            }).then(() => {
                window.location.href = "../../../view/notaris/akun_kanwil/edit_pekerjaan_kanwil.php";
            });
        <?php } ?>
        </script>
    </body>
    </html>
    <?php
}
?>
