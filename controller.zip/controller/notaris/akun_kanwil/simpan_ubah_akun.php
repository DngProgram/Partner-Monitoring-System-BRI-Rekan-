<?php
	include "../../koneksi.php";
		$id 		= $_POST['status'];
		$no 		= $_POST['id'];


			$in = mysqli_query($con,"UPDATE admin SET status='$id' where id_admin='$no'");

				if($in){


						echo"<script language='javascript'>alert('Berhasil Di Update!'); document.location='../../../view/notaris/home_kanwil.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Update!'); 
					document.location='../../../view/notaris/akun_kanwil/freeze_akun.php';</script>";
					}
?>