<?php
	include "../../koneksi.php";
		if(isset($_POST['upload'])){
		$id 				= $_POST['id'];
		$status			= $_POST['status'];
		$catatan			= $_POST['keterangan'];



			$in = mysqli_query($con,"UPDATE data_kerjaan SET status='$status', catatan='$catatan' where id='$id'");
				if($in){
						echo"<script language='javascript'>alert('Berhasil Di Approve!'); document.location='../../../view/notaris/home_uker.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Approve!'); 
					document.location='../../../view/notaris/akun_uker/progres_pekerjaan_uker_aproval.php';</script>";
					}
				}
?>	