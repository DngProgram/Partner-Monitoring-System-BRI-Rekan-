<?php
	include "../../koneksi.php";
		$no 				= $_POST['id'];
		$nama_notaris 		= $_POST['nama_notaris'];
		$nik 				= $_POST['nik'];
		$no_sk				= $_POST['no_sk'];
		$tgl_sk				= $_POST['tgl_sk'];
		$no_tlp				= $_POST['no_tlp'];
		$alamat				= $_POST['alamat'];
		$tgl_lahir	 		= $_POST['tgl_lahir'];
		$tempat_lahir 		= $_POST['tempat'];

		$sql1 =  "SELECT * FROM admin Where id_admin='$no'";
                        $result1 = mysqli_query($con, $sql1);
                        $data1 = mysqli_fetch_array($result1);
                        $uk = $data1['perubahan'];

                        if ($uk == 'Y') {
                             echo "<script language='javascript'>alert('Notaris Sudah Mengajukan Perubahan, Tunggu Hingga Di Approve oleh Kanwil Yogyakarta!'); document.location='../../../view/notaris/akun_notaris/profile_notaris.php';</script>";
    
                                }
                        else{


			$in = mysqli_query($con,"UPDATE admin SET nik='$nik', nama='$nama_notaris', tgl_lahir='$tgl_lahir', alamat='$alamat', tempat_lahir='$tempat_lahir', no_sk='$no_sk', tgl_sk='$tgl_sk', no_tlp='$no_tlp', perubahan='Y' where id_admin='$no'");
				if($in){
						echo"<script language='javascript'>alert('Perubahan Diajukan Ke Admin Kanwil BRI Yogyakarta!'); document.location='../../../view/notaris/akun_notaris/profile_notaris.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Update!'); 
					document.location='../../../view/notaris/akun_notaris/profile_notaris.php';</script>";
					}
				}
?>