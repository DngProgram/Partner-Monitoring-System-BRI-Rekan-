<?php 
		include '../../koneksi.php';
		if (isset($_POST['upload'])) {
			$nama_debitur	=$_POST['nama_debitur'];
			$nik			=$_POST['nik'];
			$unit_kerja		=$_POST['uker'];
			$nama_notaris	=$_POST['nama_notaris'];
			$status="P";

			$ekstensi_diperbolehkan	= array('pdf');
			$nama = $_FILES['file']['name'];
			$x = explode('.', $nama);
			$ekstensi = strtolower(end($x));
			$ukuran	= $_FILES['file']['size'];
			$file_tmp = $_FILES['file']['tmp_name'];
			
			$gabung=$nama_debitur."_".$unit_kerja."_".$nama_notaris."_".$nama;

        //query insert dijalankan
    		if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
				if($ukuran < 29044070){			
					move_uploaded_file($file_tmp, '../file_update_cn/'.$gabung);
					$query = mysqli_query($con,"UPDATE data_notaris SET keterangan='$gabung', status='$status' where nik='$nik'");

					if($query){
							echo"<script language='javascript'>alert('Berhasil di Update!');document.location='../../../view/notaris/akun_notaris/pilih_input.php';</script>";
					}else{
						echo"<script language='javascript'>alert('Gagal Melanjutkan!'); document.location='../../../view/notaris/akun_notaris/pilih_input.php';</script>";
					}
				}else{
					echo"<script language='javascript'>alert('Ukuruan File Terlalu Besar!'); document.location='../../../view/notaris/akun_notaris/pilih_input.php';</script>";
				}
			}else{
				echo"<script language='javascript'>alert('Ekstensi File tidak dibolehkan! hanya format PDF'); document.location='../../../view/notaris/akun_notaris/pilih_input.php';</script>";
			}

		}

		
		?>