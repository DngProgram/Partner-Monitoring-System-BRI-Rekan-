<?php
	include "../../koneksi.php";
		$id 		= $_POST['password'];
		$id_user	= $_POST['username'];
		$no 		= $_POST['id'];


			$in = mysqli_query($con,"UPDATE admin SET password='$id', username='$id_user' where id_admin='$no'");
				if($in){
						echo"<script language='javascript'>alert('User Password Berhasil Diubah!'); document.location='../../../view/notaris/akun_notaris/form_lewat.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Diubah!'); 
					document.location='../../../view/notaris/akun_notaris/ubah_password.php';</script>";
					}
?>