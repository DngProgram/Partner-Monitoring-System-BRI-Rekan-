<?php 
include '../../koneksi.php';

$nama_debitur    = isset($_POST['nama_debitur']) ? $_POST['nama_debitur'] : [];
$nama_notaris    = isset($_POST['nama_notaris']) ? $_POST['nama_notaris'] : [];
$uker            = isset($_POST['uker']) ? $_POST['uker'] : [];
$nik             = isset($_POST['nik']) ? $_POST['nik'] : [];

$jenis_pekerjaan  = isset($_POST['jenis_pekerjaan']) ? $_POST['jenis_pekerjaan'] : []; 
$jenis_akta       = isset($_POST['jenis_akta']) ? $_POST['jenis_akta'] : []; 
$keterangan_akta  = isset($_POST['keterangan_akta']) ? $_POST['keterangan_akta'] : []; 
$jenis_agunan     = isset($_POST['jenis_agunan']) ? $_POST['jenis_agunan'] : []; 
$jenis_pengikatan = isset($_POST['jenis_pengikatan']) ? $_POST['jenis_pengikatan'] : []; 
$nilai_pengikatan = isset($_POST['nilai_pengikatan']) ? $_POST['nilai_pengikatan'] : []; 
$tgl_covernote    = isset($_POST['tgl_covernote']) ? $_POST['tgl_covernote'] : []; 
$fasilitas        = isset($_POST['fasilitas']) ? $_POST['fasilitas'] : []; 
$jumlah_plafond   = isset($_POST['jumlah_plafond']) ? $_POST['jumlah_plafond'] : []; 
$jenis_ht         = isset($_POST['jenis_ht']) ? $_POST['jenis_ht'] : []; 

$tgl_penyerahan = date("Y-m-d");
$status         = "On Progress";

// Pastikan semua array punya panjang sama
$total = count($jenis_pekerjaan);

for ($i = 0; $i < $total; $i++) {
    // kalau ada index yang tidak ada, isi default kosong
    $nama_deb   = isset($nama_debitur[$i]) ? mysqli_real_escape_string($con, $nama_debitur[$i]) : '';
    $nama_not   = isset($nama_notaris[$i]) ? mysqli_real_escape_string($con, $nama_notaris[$i]) : '';
    $unit_kerja = isset($uker[$i]) ? mysqli_real_escape_string($con, $uker[$i]) : '';
    $nik_i      = isset($nik[$i]) ? mysqli_real_escape_string($con, $nik[$i]) : '';

    $pekerjaan  = isset($jenis_pekerjaan[$i]) ? mysqli_real_escape_string($con, $jenis_pekerjaan[$i]) : ''; 
    $akta       = isset($jenis_akta[$i]) ? mysqli_real_escape_string($con, $jenis_akta[$i]) : ''; 
    $ketAkta    = isset($keterangan_akta[$i]) ? mysqli_real_escape_string($con, $keterangan_akta[$i]) : ''; 
    $agunan     = isset($jenis_agunan[$i]) ? mysqli_real_escape_string($con, $jenis_agunan[$i]) : ''; 
    $pengikatan = isset($jenis_pengikatan[$i]) ? mysqli_real_escape_string($con, $jenis_pengikatan[$i]) : ''; 
    $nilai      = isset($nilai_pengikatan[$i]) ? mysqli_real_escape_string($con, preg_replace("/[^0-9]/", "", $nilai_pengikatan[$i])) : '0'; 
    $tanggal    = isset($tgl_covernote[$i]) ? mysqli_real_escape_string($con, $tgl_covernote[$i]) : '';
    $fasilitas_i= isset($fasilitas[$i]) ? mysqli_real_escape_string($con, $fasilitas[$i]) : '';
    $plafond_i  = isset($jumlah_plafond[$i]) ? mysqli_real_escape_string($con, preg_replace("/[^0-9]/", "", $jumlah_plafond[$i])) : '0'; 
    $ht         = isset($jenis_ht[$i]) ? mysqli_real_escape_string($con, $jenis_ht[$i]) : '';

    // hitung tanggal jatuh tempo (90 hari)
    $tanggal_mulai = $tgl_penyerahan;
    $lama_jatuh_tempo = 90;
    $timestamp_mulai = strtotime($tanggal_mulai);
    $tanggal_jatuh_tempo = date("Y-m-d", strtotime("+$lama_jatuh_tempo days", $timestamp_mulai));
    $tanggal_hari_ini = date("Y-m-d");

    $selisih = floor((strtotime($tanggal_jatuh_tempo) - strtotime($tanggal_hari_ini)) / 86400);  

    if ($selisih > 30) {
        $hasila = "Case Khusus";
    } elseif ($selisih < 30) {
        $hasila = "No Case";
    } else {
        $hasila = "-";
    }

    $hasil = trim($akta . " " . $agunan);

    // Gunakan data yang sudah difilter per index
    $sql = "INSERT INTO data_kerjaan 
        (nik, nama_debitur, unit_kerja, nama_notaris, jenis_pekerjaan, jenis_agunan, keterangan, 
         jenis_pengikatan, nilai_pengikatan, tgl_covernote, tgl_penyerahan, status, kd_debitur, fasilitas, plafond, ket_HT)
        VALUES 
        ('$nik_i','$nama_deb','$unit_kerja','$nama_not','$pekerjaan','$hasil','$ketAkta',
         '$pengikatan','$nilai','$tanggal','$tgl_penyerahan','$status','$hasila','$fasilitas_i','$plafond_i','$ht')";

    mysqli_query($con, $sql) or die("Error simpan baris ke-$i : " . mysqli_error($con));
}

if ($total > 0) {
    echo "<script>
            alert('Semua data pekerjaan berhasil disimpan!');
            window.location='../../../view/notaris/akun_notaris/index.php';
          </script>";
} else {
    echo "<script>
            alert('Tidak ada data yang disimpan!');
            window.location='../../../view/notaris/akun_notaris/pilih_input.php';
          </script>";
}
?>
