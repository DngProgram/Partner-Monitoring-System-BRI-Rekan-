<?php
	include "../../koneksi.php";
		if(isset($_POST['upload'])){
		$id 		= $_POST['id'];
		$status		= $_POST['status'];
		$keterangan	= $_POST['keterangan'];
		$debitur	= $_POST['debitur'];
		$fasilitas	= $_POST['fasilitas'];
		$plafond	= $_POST['plafond'];
		$jenis_pekerjaan	= $_POST['jenis_pekerjaan'];
		$nik		= $_POST['nik'];
		$nama_notaris		= $_POST['nama_notaris'];
		$unit_kerja		= $_POST['unit_kerja'];

		if (!isset($_FILES['file']) || $_FILES['file']['error'] != 0) {
        die('File wajib diupload!');
    }

    $allowed_ext = ['pdf'];
    $nama_file   = $_FILES['file']['name'];
    $tmp_file    = $_FILES['file']['tmp_name'];
    $size_file   = $_FILES['file']['size'];
    $ext         = strtolower(pathinfo($nama_file, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed_ext)) {
        die("<script language='javascript'>alert('Format file harus PDF!'); document.location='../../../view/notaris/akun_notaris/update_data_notaris_revisi.php?id=".$id."';</script>");
    }

    if ($size_file > 2097152) { // 2 MB
        die("<script language='javascript'>alert('Ukuran file maksimal 2 MB!'); document.location='../../../view/notaris/akun_notaris/update_data_notaris_revisi.php?id=".$id."';</script>");
    }

    // ========================
    // RENAME FILE (AMAN)
    // ========================
    $nama_file_baru = ($debitur. "_" . $unit_kerja. "_". $nama_notaris. "_". $nama_file) . '.pdf';
    $folder = '../file/';

    if (!move_uploaded_file($tmp_file, $folder . $nama_file_baru)) {
        die("<script language='javascript'>alert('Gagal Menyimpan!'); document.location='../../../view/notaris/akun_notaris/update_data_notaris_revisi.php?id=".$id."';</script>");
    }

    // ========================
    // GENERATE KODE DEBITUR
    // ========================
    $jml = mysqli_num_rows(mysqli_query($con, "SELECT id FROM data_kerjaan")) + 1;
    $kodeNsh = "DEB-" . date('dmy') . "-" . $jml;

    // ========================
    // SIMPAN KE DATABASE
    // ========================
    $query = mysqli_query($con, "
        UPDATE data_kerjaan SET nik='$nik', nama_debitur='$debitur', status='$status', catatan='$keterangan', upload_berkas='$nama_file_baru', fasilitas='$fasilitas', plafond='$plafond', jenis_pekerjaan='$jenis_pekerjaan' where id='$id'");

    if ($query) {
        $id = mysqli_insert_id($con);
        echo "<script>
    			alert('Update Revisi Berhasil Disimpan!');
    			window.location='../../../view/notaris/akun_notaris/progres_pekerjaan_notaris_revisi.php';
				</script>";
				exit;
    } else {
        die(mysqli_error($con));
    }
		}
?>	