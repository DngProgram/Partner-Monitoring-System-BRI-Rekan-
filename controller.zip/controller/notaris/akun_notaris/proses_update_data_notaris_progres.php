<?php
	include "../../koneksi.php";
		if(isset($_POST['upload'])){
		$id 		= $_POST['id'];
		$status		= "Pending Approval";
		$keterangan	= $_POST['keterangan'];
		$debitur	= $_POST['debitur'];
		$nama_notaris		= $_POST['nama_notaris'];
		$unit_kerja		= $_POST['unit_kerja'];

		if (!isset($_FILES['file']) || $_FILES['file']['error'] != 0) {
        die('File wajib diupload!');
    }

    $allowed_ext = ['pdf'];
    $nama_file   = $_FILES['file']['name'];
    $tmp_file    = $_FILES['file']['tmp_name'];
    $size_file   = $_FILES['file']['size'];
    $ext         = strtolower(pathinfo($nama_file, PATHINFO_EXTENSION));
    $bukti_file   = "Bukti Selesai";

    if (!in_array($ext, $allowed_ext)) {
        die("<script language='javascript'>alert('Format file harus PDF!'); document.location='../../../view/notaris/akun_notaris/update_data_notaris_progres.php?id=".$id."';</script>");
    }

    if ($size_file > 2097152) { // 2 MB
        die("<script language='javascript'>alert('Ukuran file maksimal 2 MB!'); document.location='../../../view/notaris/akun_notaris/update_data_notaris_progres.php?id=".$id."';</script>");
    }

    // ========================
    // RENAME FILE (AMAN)
    // ========================
    $nama_file_baru = ($debitur. "_" . $unit_kerja. "_". $nama_notaris. "_". $nama_file ."_". $bukti_file) . '.pdf';
    $folder = '../file/';

    if (!move_uploaded_file($tmp_file, $folder . $nama_file_baru)) {
        die("<script language='javascript'>alert('Gagal Menyimpan!'); document.location='../../../view/notaris/akun_notaris/update_data_notaris_progres.php?id=".$id."';</script>");
    }
    $jml = mysqli_num_rows(mysqli_query($con, "SELECT id FROM data_kerjaan")) + 1;
    $kodeNsh = "DEB-" . date('dmy') . "-" . $jml;

    // ========================
    // SIMPAN KE DATABASE
    // ========================
    $query = mysqli_query($con, "
        UPDATE data_kerjaan SET status='$status', keterangan='$keterangan', upload_berkas='$nama_file_baru' where id='$id'");

    if ($query) {
        $id = mysqli_insert_id($con);
        echo "<script>
    			alert('Update Berhasil Disimpan!');
    			window.location='../../../view/notaris/akun_notaris/progres_pekerjaan_notaris_progres.php';
				</script>";
				exit;
    } else {
        die(mysqli_error($con));
    }
		}

?>