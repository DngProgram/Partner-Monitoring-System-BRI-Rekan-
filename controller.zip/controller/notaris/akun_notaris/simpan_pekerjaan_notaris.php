<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include '../../koneksi.php';

if (isset($_POST['upload'])) {

    // ========================
    // AMBIL DATA FORM
    // ========================
    $nama_debitur   = mysqli_real_escape_string($con, $_POST['nama_debitur']);
    $nik            = mysqli_real_escape_string($con, $_POST['nik']);
    $unit_kerja     = mysqli_real_escape_string($con, $_POST['uker']);
    $nama_notaris   = mysqli_real_escape_string($con, $_POST['nama_notaris']);
    $tgl_penyerahan = $_POST['tgl_penyerahan'];
    $tgl_covernote  = $_POST['tgl_covernote'];

    // ========================
    // CEK NIK DUPLIKAT
    // ========================
    $cek = mysqli_num_rows(mysqli_query(
        $con,
        "SELECT nik FROM data_notaris WHERE nik='$nik'"
    ));

    if ($cek > 0) {
        echo "<script>
            alert('Debitur sudah terdaftar!');
            window.location='../../../view/notaris/akun_notaris/input_pekerjaan_notaris1.php';
        </script>";
        exit;
    }

    // ========================
    // VALIDASI FILE
    // ========================
    if (!isset($_FILES['file']) || $_FILES['file']['error'] != 0) {
        die('File wajib diupload!');
    }

    $allowed_ext = ['pdf'];
    $nama_file   = $_FILES['file']['name'];
    $tmp_file    = $_FILES['file']['tmp_name'];
    $size_file   = $_FILES['file']['size'];
    $ext         = strtolower(pathinfo($nama_file, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed_ext)) {
        die("<script language='javascript'>alert('Format file harus PDF!'); document.location='../../../view/notaris/akun_notaris/input_pekerjaan_notaris1.php';</script>");
    }

    if ($size_file > 2097152) { // 2 MB
        die("<script language='javascript'>alert('Ukuran file maksimal 2 MB!'); document.location='../../../view/notaris/akun_notaris/input_pekerjaan_notaris1.php';</script>");
    }

    // ========================
    // RENAME FILE (AMAN)
    // ========================
    $nama_file_baru = ($nama_debitur. "_" . $unit_kerja. "_". $nama_notaris. "_". $nama_file) . '.pdf';
    $folder = '../file/';

    if (!move_uploaded_file($tmp_file, $folder . $nama_file_baru)) {
        die("<script language='javascript'>alert('Gagal Menyimpan!'); document.location='../../../view/notaris/akun_notaris/input_pekerjaan_notaris1.php';</script>");
    }

    // ========================
    // GENERATE KODE DEBITUR
    // ========================
    $jml = mysqli_num_rows(mysqli_query($con, "SELECT id FROM data_notaris")) + 1;
    $kodeNsh = "DEB-" . date('dmy') . "-" . $jml;

    // ========================
    // SIMPAN KE DATABASE
    // ========================
    $query = mysqli_query($con, "
        INSERT INTO data_notaris
        (
            nama_debitur,
            nik,
            unit_kerja,
            nama_notaris,
            tgl_penyerahan,
            tgl_covernote,
            upload_berkas,
            kd_debitur
        ) VALUES (
            '$nama_debitur',
            '$nik',
            '$unit_kerja',
            '$nama_notaris',
            '$tgl_penyerahan',
            '$tgl_covernote',
            '$nama_file_baru',
            '$kodeNsh'
        )
    ");

    if ($query) {
        $id = mysqli_insert_id($con);
        echo "<script>
    			alert('Debitur Baru Berhasil Disimpan!');
    			window.location='../../../view/notaris/akun_notaris/pilih_input.php';
				</script>";
				exit;
    } else {
        die(mysqli_error($con));
    }
}
?>
