<?php
	include "../../koneksi.php";
		if(isset($_POST['upload'])){
		$id 			= $_POST['id'];
		$status			= "On Progress";
		$keterangan		= $_POST['keterangan'];
		$tgl_covernote	= $_POST['tgl_covernote'];
		$catatan		= "Sudah Di ajukan Perpanjangan";
		$tgl_now        = date("Y-m-d");

		$sql1 =  "SELECT * FROM data_kerjaan Where id='$id'";
                        $result1 = mysqli_query($con, $sql1);
                        $data1 = mysqli_fetch_array($result1);
                        $uk = $data1['catatan'];

                        if ($uk == 'Sudah Di ajukan Perpanjangan') {
                             echo "<script language='javascript'>alert('Notaris Sudah Mengajukan Perpanjangan, Tunggu Hingga Di Approve oleh Unit Kerja!'); document.location='../../../view/notaris/akun_notaris/progres_pekerjaan_notaris_pending.php';</script>";
    
                                }
                        else{

			$in = mysqli_query($con,"UPDATE data_kerjaan SET status='$status', keterangan='$keterangan', catatan='$catatan', tgl_covernote='$tgl_covernote', tgl_penyerahan='$tgl_now' where id='$id'");
				if($in){
						echo"<script language='javascript'>alert('Berhasil Di ajukan Update!'); document.location='../../../view/notaris/akun_notaris/form_lewat.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Update!'); 
					document.location='../../../view/notaris/akun_notaris/progres_pekerjaan_notaris_pending.php';</script>";
					}
                }
		}
?>	