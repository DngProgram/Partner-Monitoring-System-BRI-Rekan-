<?php
	include "../../koneksi.php";
		$nik		= $_POST['nik'];
		$nama		= $_POST['nama'];
		$no_sk		= $_POST['no_sk'];
		$tgl_sk 	= $_POST['tgl_sk'];
		$lahir	 	= $_POST['lahir'];
		$tgl_lahir  = $_POST['tgl_lahir'];
		$email		= $_POST['email'];
        $no_hp    	= $_POST['no_hp'];
        $username   = $_POST['username'];
		$password	= $_POST['password'];
		$tgl_msk	= date('Y-m-d');
		$akun		= ('mitra');

        $ceknik    =mysqli_num_rows (mysqli_query($con,"SELECT nik FROM admin WHERE nik='$_POST[nik]'"));
    	if ($ceknik > 0) {
        		echo "<script language='javascript'>alert('Notaris Sudah Terdaftar!'); document.location='../../index.php';</script>";
    
			}
    else{
			$in = mysqli_query($con,"INSERT INTO admin VALUES('','$nik','$nama','$no_sk','$tgl_sk','$lahir','$tgl_lahir','$email','$no_hp','$username','$password','$tgl_msk','$akun','Belum Aktif')");
				if($in){
						echo"<script language='javascript'>alert('Berhasil Mendaftar!'); document.location='../../../index.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Mendaftar, pastikan data sesuai!'); 
					document.location='../../../view/notaris/home_notaris.php';</script>";
					}
					
    }
?>