<?php
	include "../../koneksi.php";
	if (isset($_POST['upload'])) {
		$id 		= $_POST['id'];
		$id2 		= $_POST['id2'];
		$status		= $_POST['status'];
		$keterangan	= $_POST['keterangan'];
		$nama_debitur	= $_POST['nama_debitur'];
		$nama_notaris	= $_POST['nama_notaris'];
		$unit_kerja	= $_POST['unit_kerja'];

		if (!isset($_FILES['file']) || $_FILES['file']['error'] != 0) {
        die('File wajib diupload!');
    }

    $allowed_ext = ['pdf'];
    $nama_file   = $_FILES['file']['name'];
    $tmp_file    = $_FILES['file']['tmp_name'];
    $size_file   = $_FILES['file']['size'];
    $ext         = strtolower(pathinfo($nama_file, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed_ext)) {
        die("<script language='javascript'>alert('Format file harus PDF!'); document.location='../../../view/notaris/akun_notaris/update_data_notaris.php?id=$id';</script>");
    }

    if ($size_file > 2097152) { // 2 MB
        die("<script language='javascript'>alert('Ukuran file maksimal 2 MB!'); document.location='../../../view/notaris/akun_notaris/update_data_notaris.php?id=$id';</script>");
    }

    // ========================
    // RENAME FILE (AMAN)
    // ========================
    $nama_file_baru = ($nama_debitur. "_" . $unit_kerja. "_". $nama_notaris. "_". $nama_file) . '.pdf';
    $folder = '../file/';

    if (!move_uploaded_file($tmp_file, $folder . $nama_file_baru)) {
        die("<script language='javascript'>alert('Gagal Menyimpan!'); document.location='../../../view/notaris/akun_notaris/input_pekerjaan_notaris1.php';</script>");
    }


			$in = mysqli_query($con,"UPDATE data_kerjaan SET status='$status', catatan='$keterangan', upload_berkas='$nama_file_baru' where id='$id'");
				if($in){
						echo"<script language='javascript'>alert('Berhasil Di Update!'); document.location='../../../view/notaris/akun_notaris/detail_data_pekerjaan_notaris.php?id=$id2';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Update!'); 
					document.location='../../../view/notaris/akun_notaris/update_data_notaris.php?id=$id';</script>";
					}
				}
?>