<?php
if (isset($_GET['file'])) {

    $file = basename($_GET['file']); // cegah ../
    $filepath = __DIR__ . "/file/" . $file;

    if (file_exists($filepath)) {

        // bersihin output buffer biar ga rusak
        if (ob_get_level()) {
            ob_end_clean();
        }

        header("Content-Description: File Transfer");
        header("Content-Type: application/pdf");
        header("Content-Disposition: attachment; filename=\"$file\"");
        header("Content-Length: " . filesize($filepath));
        header("Cache-Control: no-cache");
        header("Pragma: no-cache");
        header("Expires: 0");

        readfile($filepath);
        exit;

    } else {
        echo "File tidak ditemukan!";
    }

} else {
    echo "Parameter file tidak ada!";
}
?>