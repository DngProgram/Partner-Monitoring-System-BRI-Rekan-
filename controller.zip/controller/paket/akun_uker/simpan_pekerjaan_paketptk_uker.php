<?php 
		include '../../koneksi.php';
		if($_POST['upload']){
			$nama_debitur	=$_POST['nama_debitur'];
			$unit_kerja		=$_POST['uker'];
            $plafond        =$_POST['plafond'];
			$suplesi		=$_POST['suplesi'];
			$tgl_penyerahan	=date('Y-m-d');
			$total			=$_POST['total'];
			$perihal		=$_POST['perihal'];
			$fasilitas      =$_POST['fasilitas'];
            $pembina  =$_POST['pembina'];
            $petugas  =$_POST['petugas'];
            $ao  =$_POST['ao'];
            $status="proses COP";
            $ket=$_POST['keterangan'];
            $ket2=$_POST['keterangan2'];
            date_default_timezone_set('Asia/Jakarta');
            $histori=date('d F Y, H:i:s a');

					$query = mysqli_query($con,"INSERT INTO data_ptk_kol VALUES('', '$tgl_penyerahan','$unit_kerja','$nama_debitur','$plafond','$suplesi','$total','$perihal','$fasilitas','$pembina','$petugas','$ao','-','$status','$ket','$ket2','-> Diteruskan ke CRO, $histori')");
					if($query){
						echo"<script language='javascript'>alert('Paket Berhasil dibuat!'); document.location='../../../view/paket/akun_uker/index.php';</script>";
					}else{
						echo"<script language='javascript'>alert('Pekerjaan Gagal dibuat!'); document.location='../../../view/paket/akun_uker/input_izin_uker_paket.php';</script>";
					}
		}
		?>