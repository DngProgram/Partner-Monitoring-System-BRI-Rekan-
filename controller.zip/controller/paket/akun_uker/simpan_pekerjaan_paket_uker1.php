<?php 
		include '../../koneksi.php';
		if($_POST['upload']){
			$nama_debitur	=$_POST['nama_debitur'];
			$unit_kerja		=$_POST['uker'];
            $restruk        =$_POST['restruk'];
			$os=$_POST['os'];
			$tgl_penyerahan	=date('Y-m-d');
			$kolek			="-";
			$kolekini		=$_POST['kolekini'];
			$segmen	        =$_POST['segmen'];
            $pemutus  =$_POST['pemutus'];
            $pembina  =$_POST['pembina'];
            $petugas  =$_POST['petugas'];
            $ao  =$_POST['ao'];
            $status="proses COP";
            $paket="noncovid";
            $cif=$_POST['cif'];
            $rekening=$_POST['rekening'];
			date_default_timezone_set('Asia/Jakarta');
            $histori=date('d F Y, H:i:s a');

            $query = mysqli_query($con,"INSERT INTO data_restruk VALUES('', '$cif','$tgl_penyerahan','$unit_kerja','$nama_debitur','$restruk','$os','$segmen','$pemutus','$petugas','$kolekini','$kolek','$pembina','$ao','-','$status','$paket','$rekening','-> Diteruskan ke CRO, $histori')");
					if($query){
						echo"<script language='javascript'>alert('Paket Berhasil dibuat!'); document.location='../../../view/paket/akun_uker/index.php';</script>";
					}else{
						echo"<script language='javascript'>alert('Pekerjaan Gagal dibuat!'); document.location='../../../view/paket/akun_uker/input_restruk_uker_paket1.php';</script>";
					}
		}
		?>