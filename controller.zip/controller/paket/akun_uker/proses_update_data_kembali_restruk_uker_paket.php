<?php
	include "../../koneksi.php";
			$nama_debitur	=$_POST['nama_debitur'];
			$unit_kerja		=$_POST['uker'];
            $restruk        =$_POST['restruk'];
			$os=$_POST['os'];
			$tgl_penyerahan	=date('Y-m-d');
			$kolekini		=$_POST['kolekini'];
			$segmen	        =$_POST['segmen'];
            $pemutus  =$_POST['pemutus'];
            $pembina  =$_POST['pembina'];
            $petugas  =$_POST['petugas'];
            $ao  =$_POST['ao'];
            $status="proses COP";
		$id 		= $_POST['id'];
		$cif		= $_POST['cif'];
		$rekening	= $_POST['no_rekening'];
		date_default_timezone_set('Asia/Jakarta');
        $histori=date('d F Y, H:i:s a');

        $sql =  "SELECT * FROM data_restruk Where nomor='$id'";
        $result = mysqli_query($con, $sql);
        $data = mysqli_fetch_array($result);

        $histori2=$data['histori'];
		if ($status=="proses CRA") {
			$hasil= "$histori2<br>
				  	 -> Diteruskan ke CRA, $histori";
			# code...
		}elseif ($status=="Revisi") {
			$hasil= "$histori2<br>
				  	 -> Dikembalikan ke Cabang, $histori";
			# code...
		}elseif ($status=="proses Pemutus") {
			$hasil= "$histori2<br>
				  	 -> Diteruskan ke Pemutus, $histori";
			# code...
		}elseif ($status=="proses COP") {
			$hasil= "$histori2<br>
				  	 -> Diteruskan ke CRO, $histori";
			# code...
		}elseif ($status=="proses CRR") {
			$hasil= "$histori2<br>
				  	 -> Diteruskan ke CRR, $histori";
			# code...
		}elseif ($status=="proses CLF") {
			$hasil= "$histori2<br>
				  	 -> Diteruskan ke CLF, $histori";
			# code...
		}


			$in = mysqli_query($con,"UPDATE data_restruk SET debitur='$nama_debitur', restruk_ke='$restruk', os_restruk='$os', segmen='$segmen', putusan='$pemutus', petugas_adk='$petugas', kolek='$kolekini', wp_pembina='$pembina', nama_ao='$ao', status='$status', keterangan='Sudah Di perbaiki', cif='$cif', no_rekening='$rekening', histori='$hasil' where nomor='$id'");
				if($in){
						echo"<script language='javascript'>alert('Berhasil Di Update!'); document.location='../../../view/paket/akun_uker/index.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Update!'); 
					document.location='../../../view/data_kembali_restruk_uker_paket.php';</script>";
					}
?>	