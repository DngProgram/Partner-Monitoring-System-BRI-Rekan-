<?php
	include "../../koneksi.php";
		$id 			= $_POST['id'];
		$nama_debitur	= $_POST['nama_debitur'];
		$plafond		= $_POST['plafond_awal'];
		$suplesi		= $_POST['suplesi'];
		$total_eksposur	= $_POST['total_eksposur'];
		$ket_total		= $_POST['ket_surat'];
		$perihal		= $_POST['perihal'];
		$pic			= $_POST['pic_adk'];
		$fasilitas		= $_POST['fasilitas'];
		$wp_pembina		= $_POST['pembina'];
		$ao				= $_POST['nama_ao'];
		$keterangan		= $_POST['keterangan'];


			$in = mysqli_query($con,"UPDATE data_perubahan_syarat SET status='proses COP', nama_debitur='$nama_debitur', plafond_awal='$plafond', suplesi='$suplesi', total_eksposur='$total_eksposur', perihal_surat='$perihal', fasilitas_kredit='$fasilitas', wp_pembina='$wp_pembina', pic_adk='$pic', nama_ao='$ao', keterangan='$keterangan', ket_surat='$ket_total' where nomor='$id'");
				if($in){
						echo"<script language='javascript'>alert('Berhasil Di Ajukan!'); document.location='../../../view/paket/akun_uker/index.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Di Ajukan!'); 
					document.location='../../../view/paket/akun_uker/data_kembali_syarat_uker_paket.php';</script>";
					}
?>	