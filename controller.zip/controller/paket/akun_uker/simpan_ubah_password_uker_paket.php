<?php
	include "../../koneksi.php";
		$id 		= $_POST['password'];
		$no 		= $_POST['id'];


			$in = mysqli_query($con,"UPDATE admin SET password='$id' where id_admin='$no'");
				if($in){
						echo"<script language='javascript'>alert('Berhasil Di Update!'); document.location='../../../view/paket/akun_uker/index.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Update!'); 
					document.location='../../../view/paket/akun_uker/ubah_password_uker_paket.php';</script>";
					}
?>