<?php
	include "../../koneksi.php";
		$id 			= $_POST['id'];
		$nama_debitur	= $_POST['nama_debitur'];
		$plafond		= $_POST['plafond_awal'];
		$suplesi		= $_POST['suplesi'];
		$total_eksposur	= $_POST['total_eksposur'];
		$ket_total		= $_POST['ket_surat'];
		$perihal		= $_POST['perihal'];
		$pic			= $_POST['pic_adk'];
		$fasilitas		= $_POST['fasilitas'];
		$wp_pembina		= $_POST['pembina'];
		$ao				= $_POST['nama_ao'];
		$keterangan		= $_POST['keterangan'];
		$status			="proses COP";

		date_default_timezone_set('Asia/Jakarta');
        $histori=date('d F Y, H:i:s a');

        $sql =  "SELECT * FROM data_adk Where nomor='$id'";
        $result = mysqli_query($con, $sql);
        $data = mysqli_fetch_array($result);

        $histori2=$data['histori'];
		if ($status=="proses CRA") {
			$hasil= "$histori2<br>
				  	 -> Diteruskan ke CRA, $histori";
			# code...
		}elseif ($status=="Revisi") {
			$hasil= "$histori2<br>
				  	 -> Dikembalikan ke Cabang, $histori";
			# code...
		}elseif ($status=="proses Pemutus") {
			$hasil= "$histori2<br>
				  	 -> Diteruskan ke Pemutus, $histori";
			# code...
		}elseif ($status=="proses COP") {
			$hasil= "$histori2<br>
				  	 -> Diteruskan ke CRO, $histori";
			# code...
		}elseif ($status=="proses CRR") {
			$hasil= "$histori2<br>
				  	 -> Diteruskan ke CRR, $histori";
			# code...
		}elseif ($status=="proses CLF") {
			$hasil= "$histori2<br>
				  	 -> Diteruskan ke CLF, $histori";
			# code...
		}


			$in = mysqli_query($con,"UPDATE data_adk SET status='proses COP', nama_debitur='$nama_debitur', plafond_awal='$plafond', suplesi='$suplesi', total_eksposur='$total_eksposur', perihal_surat='$perihal', fasilitas_kredit='$fasilitas', wp_pembina='$wp_pembina', pic_adk='$pic', nama_ao='$ao', keterangan='$keterangan', ket_surat='$ket_total', histori='$hasil' where nomor='$id'");
				if($in){
						echo"<script language='javascript'>alert('Berhasil Di Ajukan!'); document.location='../../../view/paket/akun_uker/index.php';</script>";
				}else{
						echo"<script language='javascript'>alert('Gagal Di Ajukan!'); 
					document.location='../../../view/paket/akun_uker/data_kembali_nonrestruk_uker_paket.php';</script>";
					}
?>	