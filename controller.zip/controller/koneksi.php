<?php
$con = mysqli_connect("localhost","root","","u622654866_briyogya");


// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>