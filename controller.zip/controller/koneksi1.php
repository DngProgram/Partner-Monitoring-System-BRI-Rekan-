<?php

class Database
{
    var $dbhost = "localhost";
    var $username = "root";
    var $password = "";
    var $dbname = "db_cop";

    function getMySQL()
    {
        $con = mysqli_connect(
            $this->dbhost,
            $this->username,
            $this->password,
            $this->dbname
        ) or die("Gagal konek dengan error : " . mysqli_connect_error());

        if (mysqli_connect_errno()) {
            return "tidak dapat konek ke database MySQL";
        } else {
            return $con;
        }
    }
}