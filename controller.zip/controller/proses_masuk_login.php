<?php
error_reporting(0);
session_start();
include 'koneksi.php';        
$username=$_POST['username'];   
$password=$_POST['password'];   
$query=mysqli_query($con,"select * from admin where username ='$username' and password='$password'");  
$hasil=mysqli_num_rows($query);
if($hasil==TRUE){       
        $_SESSION['username']=$username;
        $query=mysqli_query($con,"select * from admin where username ='$username'");    
        $hasil=mysqli_fetch_array($query);
        $coba1=$hasil['status'];
        $coba=$hasil['akun'];       
        if($coba=='mitra'){
            if ($coba1=='Aktif') {
                # code...
                $_SESSION['username'] = $username;
                echo '<script language="javascript">alert("Login Berhasil!"); 
                document.location=".././view/notaris/akun_notaris/index.php";</script>';
            }elseif ($coba1=='Nonaktif') {
                # code...
                echo '<script language="javascript">alert("Maaf Akun Anda Di Nonaktifkan! Silahkan Kontak Admin Kanwil BRI Yogyakarta"); document.location="../index.php";</script>';
            }elseif ($coba1=='Belum Aktif') {
                # code...
                echo '<script language="javascript">alert("Maaf Akun Anda Belum Aktif! Silahkan Kontak Admin Kanwil BRI Yogyakarta"); document.location="../index.php";</script>';
            }
            
            }
                   else if($coba=='ro'){
            $_SESSION['username'] = $username;                  
                    echo '<script language="javascript">alert("Login Berhasil!"); document.location=".././view/notaris/home_uker.php";</script>';
                }   
                    else if($coba=='roj'){
            $_SESSION['username'] = $username;                  
                    echo '<script language="javascript">alert("Login Berhasil!"); document.location=".././view/notaris/home_kanwil.php";</script>';
                }   
    }
        if($hasil==TRUE){

                echo '<script language="javascript">alert("Login Gagal! Username atau Password anda Salah"); document.location="../index.php";</script>';
            }
    else {
            echo '<script language="javascript">alert("Login Gagal! Akun anda belum terdaftar"); document.location="../index.php";</script>';
        }
?>