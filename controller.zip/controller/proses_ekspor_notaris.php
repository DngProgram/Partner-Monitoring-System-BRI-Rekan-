<?php 
 //koneksi kedatabase
include "koneksi.php";

 // nama file
 $filename="data cop-".date('Ymd').".xls";

 $tgl_awal     	=$_POST['tgl'];
 $tgl_akhir		=$_POST['tgl1'];
 $uker1			=$_POST['nama_notaris'];

 //header info for browser
 header("Content-Type: application/vnd-ms-excel"); 
    header('Content-Disposition: attachment; filename="' . $filename . '";');

    //menampilkan data sebagai array dari tabel produk
    $out=array();
 $sql=mysqli_query($con,"SELECT * FROM data_kerjaan where tgl_penyerahan='$tgl' and nama_notaris='$uker1'");
 while($data=mysqli_fetch_assoc($sql)) $out[]=$data;

 $show_coloumn = false;
 foreach($out as $record) {
 if(!$show_coloumn) {
 //menampilkan nama kolom di baris pertama
 echo implode("\t", array_keys($record)) . "\n";
 $show_coloumn = true;
 }
 // looping data dari database
 echo implode("\t", array_values($record)) . "\n";
 } 
 exit;
?>